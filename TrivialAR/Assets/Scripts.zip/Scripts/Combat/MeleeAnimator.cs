using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Combat
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Animation))]
    public sealed class MeleeAnimator : MonoBehaviour
    {
        [Header("Clips (Legacy Animation)")]
        public string idleClip = "Idle_Combat";
        public string walkClip = "Walking_D_Skeletons";
        public List<string> attackClips = new()
        {
            "Unarmed_Melee_Attack_Punch_A",
            "Unarmed_Melee_Attack_Punch_B",
            "Unarmed_Melee_Attack_Kick"
        };
        public List<string> dodgeClips = new() { "Dodge_Left", "Dodge_Right", "Dodge_Forward", "Dodge_Backward" };
        public List<string> hitClips   = new() { "Hit_A", "Hit_B" };
        public string deathClip = "Death_C_Skeletons";

        Animation _anim;

        void Awake()
        {
            _anim = GetComponent<Animation>();
            _anim.playAutomatically = false;
            _anim.cullingType = AnimationCullingType.AlwaysAnimate;

            SetWrap(idleClip, WrapMode.Loop);
            SetWrap(walkClip, WrapMode.Loop);
            foreach (var n in attackClips) SetWrap(n, WrapMode.Once);
            foreach (var n in dodgeClips)  SetWrap(n, WrapMode.Once);
            foreach (var n in hitClips)    SetWrap(n, WrapMode.Once);
            SetWrap(deathClip, WrapMode.Once);

            // One-time validation (warn if names don’t match)
            _ = HasClip(idleClip, true);
            _ = HasClip(walkClip, true);
            foreach (var n in attackClips) _ = HasClip(n, true);
            foreach (var n in dodgeClips)  _ = HasClip(n, true);
            foreach (var n in hitClips)    _ = HasClip(n, true);
            _ = HasClip(deathClip, true);
        }

        public void PlayIdle() => CrossFadeIf(idleClip, 0.1f);
        public void PlayWalk(float fade = 0.1f) => CrossFadeIf(walkClip, fade);

        public void PlayOnceThenIdle(string clip, float fade)
        {
            if (!HasClip(clip)) { PlayIdle(); return; }
            var c = _anim.GetClip(clip);
            c.wrapMode = WrapMode.Once;
            SetWrap(idleClip, WrapMode.Loop);
            _anim.CrossFade(clip, fade);
            _anim.CrossFadeQueued(idleClip, 0.1f, QueueMode.CompleteOthers); // avoid freeze
        }

        public void PlayHitThenIdle(string hitClip, float fade = 0.05f)
        {
            if (!HasClip(hitClip)) return;
            var c = _anim.GetClip(hitClip);
            c.wrapMode = WrapMode.Once;
            _anim.CrossFade(hitClip, fade);
            _anim.CrossFadeQueued(idleClip, 0.1f, QueueMode.CompleteOthers);
        }

        public void PlayDeath()
        {
            if (!HasClip(deathClip)) return;
            var c = _anim.GetClip(deathClip);
            c.wrapMode = WrapMode.Once;
            _anim.CrossFade(deathClip, 0.15f);
        }

        public string PickAttack() => PickClip(attackClips);
        public string PickDodge()  => PickClip(dodgeClips);
        public string PickHit()    => PickClip(hitClips);

        public void EnsureIdlePlaying()
        {
            if (_anim && !string.IsNullOrEmpty(idleClip) && !_anim.IsPlaying(idleClip))
                PlayIdle();
        }

        bool HasClip(string name, bool warn = false)
        {
            if (_anim == null || string.IsNullOrEmpty(name)) return false;
            bool ok = _anim.GetClip(name) != null;
            if (!ok && warn) Debug.LogWarning($"[Combat] Clip '{name}' not found on {gameObject.name}", this);
            return ok;
        }

        void SetWrap(string clip, WrapMode mode)
        {
            if (string.IsNullOrEmpty(clip) || _anim == null) return;
            var c = _anim.GetClip(clip);
            if (c) c.wrapMode = mode;
        }

        string PickClip(List<string> list)
        {
            if (list == null || list.Count == 0) return null;
            var valid = list.Where(n => !string.IsNullOrEmpty(n)).ToList();
            if (valid.Count == 0) return null;
            return valid[Random.Range(0, valid.Count)];
        }

        void CrossFadeIf(string clip, float fade)
        {
            if (_anim == null || string.IsNullOrEmpty(clip)) return;
            var c = _anim.GetClip(clip);
            if (c == null) return;
            if (clip.Contains("Idle") || clip.Contains("Walk")) c.wrapMode = WrapMode.Loop; // locomotion must loop
            _anim.CrossFade(clip, fade);
        }
    }
}
