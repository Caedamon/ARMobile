namespace Combat
{
    public enum Intent { Idle, Move, Attack, Dodge }
    public enum Team { Main, Enemy }
}