using Characters;
using Combat;
using Game;
using UnityEngine;

namespace Combat
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Health))]
    public sealed class MeleeCombat : MonoBehaviour
    {
        [Header("Combat")]
        public float damage = 25f;
        [Range(0f, 1f)] public float dodgeProbabilityInRange = 0f;

        [Header("FX")]
        public float knockbackStrength = 0.02f;

        Health _hp;

        void Awake() => _hp = GetComponent<Health>();

        public void ExecuteDodge(MeleeAnimator anim)
        {
            string dc = anim.PickDodge();
            anim.PlayOnceThenIdle(dc, 0.05f);
            BattleEvents.AnnounceAction(GetComponent<MeleeAI>(), "Dodge!");
        }

        public void ExecuteAttack(MeleeAI self, MeleeAI target, MeleeAnimator anim)
        {
            if (!target || target.IsDead) { anim.PlayIdle(); return; }

            var to = target.transform.position - self.transform.position; to.y = 0f;
            if (to.sqrMagnitude > 1e-6f)
                self.transform.rotation = Quaternion.LookRotation(to.normalized, Vector3.up);

            string ac = anim.PickAttack();
            anim.PlayOnceThenIdle(ac, 0.1f);

            string action = (ac != null && ac.Contains("Kick")) ? "Kick!" :
                            (ac != null && ac.Contains("Punch")) ? "Punch!" : "Attack!";
            BattleEvents.AnnounceAction(self, action);

            target.GetComponent<Health>()?.TakeDamage(damage);
            BattleEvents.AnnounceDamage(target, damage);

            if (knockbackStrength > 0f && to.sqrMagnitude > 1e-6f)
            {
                var kb = target.GetComponent<KaijuBody>() ?? target.GetComponentInChildren<KaijuBody>();
                if (kb != null) kb.ApplyKnockback(to.normalized, knockbackStrength);
            }

            var tAnim = target.GetComponent<MeleeAnimator>();
            if (tAnim != null && !target.IsDead)
            {
                var hit = tAnim.PickHit();
                if (!string.IsNullOrEmpty(hit)) tAnim.PlayHitThenIdle(hit);
            }

            if (target.IsDead)
                target.GetComponent<MeleeAnimator>()?.PlayDeath();
        }
    }
}
