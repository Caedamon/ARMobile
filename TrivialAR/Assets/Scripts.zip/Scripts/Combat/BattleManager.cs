using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Combat
{
    public class BattleManager : MonoBehaviour
    {
        [Header("Timing")]
        public float thinkTimeSeconds = 2f;
        public float resolveDelaySeconds = 0.1f;

        [Header("Discovery")]
        public bool autoDiscoverOnStart = true;
        public bool rescanEachRound = true;

        [Header("Debug")]
        public bool logRounds = true;
        public bool kickstartFirstRound = true;

        private readonly List<MeleeAI> _units = new();
        private int _roundIndex = 0;
        private bool _didKickstart = false;

        void Start()
        {
            if (autoDiscoverOnStart) DiscoverUnits();
            StartCoroutine(BattleLoop());
        }

        public void DiscoverUnits()
        {
            _units.Clear();
            _units.AddRange(FindObjectsByType<MeleeAI>(FindObjectsSortMode.None));
            if (logRounds) Debug.Log($"[Battle] DiscoverUnits → {_units.Count}");
        }

        private IEnumerator BattleLoop()
        {
            while (true)
            {
                if (rescanEachRound) DiscoverUnits();

                for (int i = _units.Count - 1; i >= 0; i--)
                {
                    var u = _units[i];
                    if (!u || u.IsDead) _units.RemoveAt(i);
                }
                if (_units.Count == 0) { yield return null; continue; }

                _roundIndex++;
                if (logRounds) Debug.Log($"[Battle] Round #{_roundIndex} — units={_units.Count}");

                if (kickstartFirstRound && !_didKickstart && _units.Count >= 2)
                {
                    foreach (var u in _units) { if (!u || u.IsDead) continue; u.CurrentInitiative = u.RollInitiative(); }
                    foreach (var u in _units) { if (!u || u.IsDead) continue; u.FinalizeIntent(); }
                    var alive = _units.Where(u => u && !u.IsDead).ToList();
                    foreach (var u in alive) u.CacheTarget(alive);
                    ResolveRound(alive);
                    _didKickstart = true;
                    yield return null;
                    continue;
                }

                foreach (var u in _units)
                {
                    if (!u || u.IsDead) continue;
                    u.CurrentInitiative = u.RollInitiative();
                    u.BeginThinking(thinkTimeSeconds);
                }

                yield return new WaitForSeconds(thinkTimeSeconds + resolveDelaySeconds);

                foreach (var u in _units)
                {
                    if (!u || u.IsDead) continue;
                    u.FinalizeIntent();
                }

                var aliveNow = _units.Where(u => u && !u.IsDead).ToList();
                foreach (var u in aliveNow) u.CacheTarget(aliveNow);

                ResolveRound(aliveNow);

                yield return null;
            }
        }

        private void ResolveRound(List<MeleeAI> alive)
        {
            var resolved = new HashSet<MeleeAI>();

            foreach (var a in alive)
            {
                if (resolved.Contains(a)) continue;

                var b = a.CachedTarget;

                if (b == null || b.IsDead)
                {
                    a.ResolveSoloIntent(a.MoveStepMeters);
                    resolved.Add(a);
                    continue;
                }

                if (b.CachedTarget == a && !resolved.Contains(b))
                {
                    ResolvePair(a, b);
                    resolved.Add(a); resolved.Add(b);
                }
                else
                {
                    a.ResolveVsOpponent(b, a.MoveStepMeters);
                    resolved.Add(a);
                }
            }
        }

        private void ResolvePair(MeleeAI a, MeleeAI b)
        {
            if (a.IsDead && b.IsDead) return;
            if (a.IsDead) { b.ResolveSoloIntent(b.MoveStepMeters); return; }
            if (b.IsDead) { a.ResolveSoloIntent(a.MoveStepMeters); return; }

            var ai = a.Intent;
            var bi = b.Intent;

            if (ai == Intent.Move && bi == Intent.Move)
            {
                float dist = Vector3.Distance(a.transform.position, b.transform.position);
                float targetDist = Mathf.Max(a.AttackRange, b.AttackRange);
                float available = Mathf.Max(0f, dist - targetDist + 1e-3f);
                float stepEach = Mathf.Min(a.MoveStepMeters, b.MoveStepMeters, available * 0.5f);

                a.ResolveVsOpponent(b, stepEach);
                b.ResolveVsOpponent(a, stepEach);
                return;
            }

            if ((ai == Intent.Dodge && bi == Intent.Attack) ||
                (bi == Intent.Dodge && ai == Intent.Attack))
            {
                if (ai == Intent.Dodge) a.ExecuteDodge();
                if (bi == Intent.Dodge) b.ExecuteDodge();
                return;
            }

            if (ai == Intent.Attack && bi == Intent.Attack)
            {
                int ia = a.CurrentInitiative, ib = b.CurrentInitiative;
                if (ia == ib) { if (Random.value < 0.5f) ia++; else ib++; }
                if (ia > ib) a.ExecuteAttack(b); else b.ExecuteAttack(a);
                return;
            }

            a.ResolveVsOpponent(b, a.MoveStepMeters);
            b.ResolveVsOpponent(a, b.MoveStepMeters);
        }
    }
}
